<?php
  include("conf/config.php");
  include("conf/auth.php");
  include('admin-layouts/header.php');
?>
    <div id="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Services</li>
      </ol>

      <div class="col-sm-8">

      <form action="services-add.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label for="name">Service Name</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Name">
        </div>

        <!-- <div class="form-group">
            <label for="name">Price</label>
            <input type="text" name="price" class="form-control" placeholder="Enter Price">
        </div> -->

        <div class="form-group">
            <label for="categories">Barber</label>
            <select class="form-control" name="stylist_id" id="stylists">
                <option value="0">-- Choose --</option>
                <?php
                    $result = mysqli_query($conn, "SELECT id, stylist_name FROM stylists");
                    while($row = mysqli_fetch_assoc($result)):
                ?>
                <option value="<?php echo $row['id'] ?>">
                <?php echo $row['stylist_name'] ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>


        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control-file form-control-lg" name="image" id="image">
        </div>


        <br><br>
        <input type="submit" class="btn btn-success" value="Add Service">
        <br><br>
      </form>
      </div>


    </div>
  </div>
<? include('admin-layouts/footer.php'); ?>