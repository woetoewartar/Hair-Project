<?php
    include("conf/config.php");

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `users` WHERE email ='$email' ";

    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if(password_verify($password, $row['password'])) {
            if($row['role']== 'admin'){
                $_SESSION['auth'] = true;
                header("location: barber-list.php");
            }else {
                header("location: index.php");
            }
        }
    }


?>