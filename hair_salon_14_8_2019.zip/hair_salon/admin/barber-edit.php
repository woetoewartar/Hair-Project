<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
    <div id="content-wrapper">
    <div class="container-fluid">

        <?php
            $id = $_GET['id'];
            $result = mysqli_query($conn, "SELECT * FROM stylists WHERE id = $id");
            $row = mysqli_fetch_assoc($result);
        ?>

      <div class=" col-sm-8 text-left">

        <form action="barber-update.php"class="fun_add" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
            <label for="name">Barber Name</label>
            <input type="text" name="name" id="name" value="<?php echo $row['stylist_name']; ?>">
            <label for="remark">Remark</label>
            <textarea name="remark" id="remark"style="width: 220px;border: 1px solid #90c322;border-radius: 5px;">
                <?php echo $row['remark']; ?>
        </textarea>
        <div class="form-group">
            <label for="image">Image</label>
            <img src="./images/<?php echo $row['bimage'] ?>" alt="" class="img-thumnail" style="width:15%;">
            <input type="file" class="form-control-file form-control-lg" name="image" id="image">
        </div>
            <br><br>
            <input type="submit" value="Update">
        </form>

      </div>


    </div>
  </div>


<? include ('admin-layouts/footer.php'); ?>