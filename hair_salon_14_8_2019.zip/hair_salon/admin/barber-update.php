<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_POST['id'];
    $name = $_POST['name'];
    $remark = $_POST['remark'];

    $image = $_FILES['image']['name'];
    $filename = pathinfo($image, PATHINFO_FILENAME);
    $fileExt = pathinfo($image, PATHINFO_EXTENSION);
    $file = $filename.'_'.time().'.'.$fileExt;

    $tmp = $_FILES['image']['tmp_name'];

    if($image) {
        //echo 'ok';
    move_uploaded_file($tmp, "images/$file");
    $sql = "UPDATE stylists SET stylist_name='$name', remark='$remark', bimage='$file', update_at=now() WHERE id = '$id' ";

    }else{
        $sql = "UPDATE stylists SET stylist_name='$name', remark='$remark', update_at=now() WHERE id = '$id' ";
    }

    mysqli_query($conn, $sql);
    header("location: barber-list.php");
?>
