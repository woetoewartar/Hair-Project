<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $getUidQuery = "SELECT * FROM orders WHERE id = $id";
    $result = mysqli_query($conn, $getUidQuery);
    $row = mysqli_fetch_assoc($result);
    $user_id = $row['user_id'];

    //set the user role according to total usage
    // $checkTotalQuery = "SELECT * FROM points WHERE user_id = '$user_id'";
    // $getTotalQuery = mysqli_query($conn, $checkTotalQuery);
    // $row2 = mysqli_fetch_assoc($getTotalQuery);


    // if($row2['total'] > 30000){//if total is greater than 10000 set the role to silver
    //     $setRoleQuery = "UPDATE users SET role='diamond', update_at=now() WHERE id = '$user_id' ";
    // }elseif($row2['total'] > 20000){
    //     $setRoleQuery = "UPDATE users SET role='gold', update_at=now() WHERE id = '$user_id' ";
    // }elseif($row2['total'] > 10000){
    //     $setRoleQuery = "UPDATE users SET role='silver', update_at=now() WHERE id = '$user_id' ";
    // }
    // mysqli_query($conn, $setRoleQuery);

    $sql1 = "DELETE FROM orders WHERE id = $id";


    mysqli_query($conn, $sql1);




    header("location: admin-order.php");
?>