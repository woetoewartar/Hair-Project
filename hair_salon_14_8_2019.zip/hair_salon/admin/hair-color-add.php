<?php
    include("conf/config.php");
    $name = $_POST['title'];
    $price = $_POST['price'];

    $sql = "INSERT INTO hair_color (
    hair_color_title, hair_color_price,
     create_at, update_at
    ) VALUES (
    '$name','$price', now(), now()
    )";
    mysqli_query($conn, $sql);
    header("location: hair-color-list.php");
?>
