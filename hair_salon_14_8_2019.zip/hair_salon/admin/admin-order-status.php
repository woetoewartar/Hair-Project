<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $status = $_GET['status'];
    mysqli_query($conn, "UPDATE orders SET
    status=$status, update_at=now() WHERE id=$id
    ");
    //get the total useage
    $addTotal = "SELECT * FROM orders WHERE id = $id AND status = 1";
    $result = mysqli_query($conn, $addTotal);
    $order = mysqli_fetch_assoc($result);
    $total = $order['hair_cut_price'] + $order['hair_color_price'] + $order['hair_care_price'];
    $user_id = $order['user_id'];
    //echo $user_id;
    //echo $total;

    //add to points
    $getPointsQuery = "SELECT * FROM points WHERE user_id = '$user_id'";
    $result = mysqli_query($conn, $getPointsQuery);
    $row = mysqli_fetch_assoc($result);
    if ($row) {
        $existing_points = $row['total'];
        $new_points = $existing_points + $total;
        $updatePointsQuery = "UPDATE points SET total = '$new_points' WHERE user_id = '$user_id'";
        $result = mysqli_query($conn, $updatePointsQuery);
        // if ($result) {
        // 	echo "updated";
        // } else {
        // 	echo "error";
        // }

    } else {
        $insertPointsQuery = "INSERT INTO points (user_id,total,create_at,update_at) VALUES ('$user_id','$total',now(),now())";
        $result = mysqli_query($conn, $insertPointsQuery);
        // if ($result) {
        // 	echo "indserte";
        // } else {
        // 	echo "error";
        // }


    }
    //set the user role according to total usage
    //set the user role according to total usage
    $checkTotalQuery = "SELECT * FROM points WHERE user_id = '$user_id'";
    $getTotalQuery = mysqli_query($conn, $checkTotalQuery);
    $row2 = mysqli_fetch_assoc($getTotalQuery);


   if($row2['total'] > 30000){//if total is greater than 10000 set the role to silver
        $setRoleQuery = "UPDATE users SET role='diamond', update_at=now() WHERE id = '$user_id' ";
    }elseif($row2['total'] > 20000){
        $setRoleQuery = "UPDATE users SET role='gold', update_at=now() WHERE id = '$user_id' ";
    }elseif($row2['total'] > 10000){
        $setRoleQuery = "UPDATE users SET role='silver', update_at=now() WHERE id = '$user_id' ";
    }
    mysqli_query($conn, $setRoleQuery);


    header("location: admin-order.php");
?>
