<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
    <div id="content-wrapper">
    <div class="container-fluid">
    <a href="services-new.php" class="new btn add_btn"><i class="fa fa-plus-circle"></i>New Service</a>

    <!-- Here Start the list of stylists -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th>Service Name</th>
              <!-- <th>Price</th> -->
              <th>Stylist</th>
              <th>Delete</th>
              <th>Edit</th>
            </tr>
          </thead>
          <?php
            $sql = "SELECT services.*,stylists.stylist_name FROM services LEFT JOIN stylists ON services.stylist_id = stylists.id
            ORDER BY services.create_at DESC";
            $result = mysqli_query($conn, $sql);
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
           <?//php var_dump($row); ?>
          <tr>
            <td style="width:15%;"><img src="./images/<?php echo $row['image']; ?>"  class="img-thumbnail"></td>
            <td><?php echo $row['title'] ?></td>
            <!-- <td><?php echo $row['price'] ?></td> -->
            <td><?php echo $row['stylist_name'] ?></td>
            <td><a href="services-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"> <i class="fa fa-trash"></i> Delete</button></a></td>
            <td><a href="services-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="fa fa-edit"></i>Edit</button></a> </td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of stylists -->
    </div>
</div>


<?php include('admin-layouts/footer.php'); ?>