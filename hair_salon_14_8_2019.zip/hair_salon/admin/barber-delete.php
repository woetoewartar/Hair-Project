<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $sql = "DELETE FROM stylists WHERE id = $id";
    mysqli_query($conn, $sql);
    header("location: barber-list.php");
?>
