<?php
  include("conf/config.php");
  include("conf/auth.php");
  include('admin-layouts/header.php');
  $id = $_GET['id'];
    $sql = "SELECT * FROM hair_color WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
?>
    <div id="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Hair Cut </li>
      </ol>

      <div class="col-sm-8">

      <form action="hair-color-update.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Name" value="<?php echo $row['hair_color_title']; ?>">
        </div>

        <div class="form-group">
            <label for="name">Price</label>
            <input type="text" name="price" class="form-control" placeholder="Enter Price" value="<?php echo $row['hair_color_price'] ?>">
        </div>

        <br><br>
        <input type="submit" class="btn btn-success" value="Update Hair Color">
        <br><br>
      </form>
      </div>


    </div>
  </div>
<? include('admin-layouts/footer.php'); ?>