<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $sql = "DELETE FROM hair_care WHERE id = $id";
    mysqli_query($conn, $sql);
    header("location: hair-care-list.php");
?>
