<?php
    session_start();
    if (empty($_SESSION['token'])) {
        $_SESSION['token'] = bin2hex(random_bytes(32));
    }
    $token = $_SESSION['token'];

    $db_host = "localhost";
    $db_user = "root";
    $db_pw   = "";
    $db_name = "hair_salon_db";

    //Create Connection
    $conn = mysqli_connect($db_host, $db_user, $db_pw);
    mysqli_select_db($conn, $db_name);

    //Check Connection
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }
    //echo "Connected <br>";
    //echo $token;
    if(isset($_SESSION['auth_user_id'])){
		$uid =  ($_SESSION['auth_user_id']);

		$result = mysqli_query($conn, "SELECT * FROM `users` WHERE id = $uid;");
        $user = mysqli_fetch_assoc($result);

        $points = mysqli_query($conn, "SELECT * FROM `points` WHERE user_id = $uid;");
		$user_points = mysqli_fetch_assoc($points);
	}
?>