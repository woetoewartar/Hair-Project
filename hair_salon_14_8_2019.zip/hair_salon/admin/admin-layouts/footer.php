
<!-- Sticky Footer -->
<footer class="sticky-footer">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright © Eaindra</span>
    </div>
  </div>
</footer>



    <!-- Page level plugin JavaScript-->
    <script src="/hair_salon/js/jquery.dataTables.js"></script>
    <script src="/hair_salon/js/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="/hair_salon/js/sb-admin.min.js"></script>


  </body>

</html>

