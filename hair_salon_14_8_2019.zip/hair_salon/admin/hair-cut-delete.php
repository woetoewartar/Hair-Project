<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $sql = "DELETE FROM hair_cut WHERE id = $id";
    mysqli_query($conn, $sql);
    header("location: hair-cut-list.php");
?>
