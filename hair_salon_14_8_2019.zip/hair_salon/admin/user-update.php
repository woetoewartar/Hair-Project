<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $sql = "UPDATE users SET name='$name', email='$email', role = '$role', update_at=now() WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("location: user-list.php");
?>
