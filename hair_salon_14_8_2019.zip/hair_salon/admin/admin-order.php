<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>

<div id="content-wrapper">
  <div class="container-fluid">
    <h1>Booking List</h1>


        <?php
            $orders = mysqli_query($conn, "SELECT * FROM orders");
        ?>

        <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Stylist</th>
                    <th>Status</th>
                    <th>Service items</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php while($order = mysqli_fetch_assoc($orders)): ?>
                <tr>
                    <td><?php
                     $uid = $order['user_id'];
                     $sql = mysqli_query($conn,"SELECT * FROM users WHERE id = '$uid' ");
                     $row = mysqli_fetch_assoc($sql);
                     echo $row['name'];

                     ?></br>
                     <?php echo $row['phone']; ?>
                    </td>

                    <td><?php
                     $sid = $order['stylist_id'];
                     $sql = mysqli_query($conn,"SELECT * FROM stylists WHERE id = '$sid' ");
                     $row = mysqli_fetch_assoc($sql);
                     echo $row['stylist_name'];

                     ?></td>

                    <td><?php if($order['status']): ?>
                            * <a href="#">
                            Undo</a>
                            <?php else: ?>
                            * <a href="admin-order-status.php?id=<?php echo $order['id'] ?>&status=1">
                            Mark as Finished</a>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?php
                        $total = $order['hair_cut_price'] + $order['hair_color_price'] + $order['hair_care_price'];
                            echo 'Hair Cut = ' .$order['hair_cut_price'].'<br>';
                            echo 'Hair Color = ' .$order['hair_color_price'].'<br>';
                            echo 'Hair Care = ' .$order['hair_care_price'].'<br>';
                            echo 'Total = '.$total .'<br>';
                            echo 'Booking Date : '.$order['bdate'].'-'.$order['btime'] .'<br>';
                        ?>
                    </td>

                    <td>
                    <p></p>

                        <a href="order-delete.php?id=<?php echo $order['id'] ?>">
                            <button class="del_btn btn danger"> <i class="fas fa-trash-alt"></i> Delete</button>
                        </a>
                    </td>

                </tr>
            <?php endwhile; ?>
        </table>
        </div>



  </div>
</div>

<?php include('admin-layouts/footer.php'); ?>