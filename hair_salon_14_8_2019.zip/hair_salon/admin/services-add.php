<?php
    include("conf/config.php");
    $name = $_POST['title'];
    $price = $_POST['price'];
    $stylist_id = $_POST['stylist_id'];
    $image = $_FILES['image']['name'];
    $filename = pathinfo($image, PATHINFO_FILENAME);
    $fileExt = pathinfo($image, PATHINFO_EXTENSION);
    $file = $filename.'_'.time().'.'.$fileExt;


    $tmp = $_FILES['image']['tmp_name'];
    if($file) {
    move_uploaded_file($tmp, "images/$file");
    }

    $sql = "INSERT INTO services (
    title, price, stylist_id,
    image, create_at, update_at
    ) VALUES (
    '$name','$price', '$stylist_id', '$file', now(), now()
    )";
    mysqli_query($conn, $sql);
    header("location: services-list.php");
?>
