<?php
  include("conf/config.php");
  include("conf/auth.php");
  include('admin-layouts/header.php');
?>
    <div id="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Hair Care</li>
      </ol>

      <div class="col-sm-8">

      <form action="hair-care-add.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Name">
        </div>

        <div class="form-group">
            <label for="name">Price</label>
            <input type="text" name="price" class="form-control" placeholder="Enter Price">
        </div>

        <br><br>
        <input type="submit" class="btn btn-success" value="Add Hair Care">
        <br><br>
      </form>
      </div>


    </div>
  </div>
<? include('admin-layouts/footer.php'); ?>