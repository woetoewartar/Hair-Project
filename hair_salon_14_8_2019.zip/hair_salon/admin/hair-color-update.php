<?php
    include("conf/config.php");
    $id = $_POST['id'];
    $title = $_POST['title'];
    $price = $_POST['price'];

    $sql = "UPDATE hair_color SET hair_color_title='$title',hair_color_price='$price',update_at=now() WHERE id = $id";

    mysqli_query($conn, $sql);
    header("location: hair-color-list.php");
?>