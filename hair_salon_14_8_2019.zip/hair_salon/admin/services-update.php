<?php
    include("conf/config.php");
    $id = $_POST['id'];
    $title = $_POST['title'];
    $price = $_POST['price'];
    $stylist_id = $_POST['stylist_id'];
    //echo $canteen_id;

    $image = $_FILES['image']['name'];
    $filename = pathinfo($image, PATHINFO_FILENAME);
    $fileExt = pathinfo($image, PATHINFO_EXTENSION);
    $file = $filename.'_'.time().'.'.$fileExt;

    $tmp = $_FILES['image']['tmp_name'];
    if($image) {
        //echo 'ok';
    move_uploaded_file($tmp, "images/$file");
    $sql = "UPDATE services SET title = '$title', stylist_id='$stylist_id',image='$file',update_at=now() WHERE id='$id' ";
    }else{
        //echo 'no';
        $sql = "UPDATE services SET title='$title', stylist_id='$stylist_id',update_at=now() WHERE id = $id";
    }
    mysqli_query($conn, $sql);
    header("location: services-list.php");
?>