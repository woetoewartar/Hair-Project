    <?php
    include("admin/conf/config.php");

    $user_id = $_SESSION['auth_user_id'];
    $stylistID = $_POST['stylistID'];
    $hairCut = $_POST['hairCut'];
    $hairColor = $_POST['hairColor'];
    $hairCare = $_POST['hairCare'];
    $bDate = $_POST['date'];
    $bTime = $_POST['time'];

    if ($hairCut == 0 && $hairColor == 0 && $hairCare == 0 ) {
        echo "Choose the one service";
    }else {
        echo "success";
        $user_add = "INSERT INTO `orders`( `user_id`, `stylist_id`, ) VALUES ($user_id,$stylistID,)";
        mysqli_query($conn,$user_add);
         echo $user_id.'<br>';
         echo $stylistID.'<br>';
        // echo $hairCut.'<br>';
        // echo $hairColor.'<br>';
        // echo $hairCare.'<br>';
        // echo $bDate.'<br>';
        // echo $bTime.'<br>';
    }


    ?>
