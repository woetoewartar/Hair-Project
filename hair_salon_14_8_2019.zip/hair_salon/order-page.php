<?php include("layouts/header.php");
$stylist_id = $_GET['id']; ?>
<!-- Breadcrumb Area Start -->
<section class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-content">
                    <h2>Our Services</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html"><i class="icon_house_alt"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Services</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Area End -->
<?php if(isset($_SESSION['auth_user_id'])): ?>
    <section class="akame-service-area">
        <div class="row">
            <div class="col-md-8">
                <form action="order.php" method="POST" id="order_form_submit">
                    <input type="hidden" name="user_id" id="user_id" value="<?php echo $_SESSION['auth_user_id']; ?>">
                    <input type="hidden" name="stylist_id" id="stylist_id" value="<?php echo $stylist_id ?>">

                    <div class="form-group">
                        <label for="hair_style" class="col-md-4 col-form-label text-md-right">Hair Style:</label>
                        <select class="choose_plan" name="hairCut" id="hairCut">
                            <option value="0">Select Hair Style:</option>
                            <?php while($row = mysqli_fetch_assoc($hair_cut_sql)): ?>
                                <option value="<?php echo $row['hair_cut_price']; ?>"><?php echo $row['hair_cut_title']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="hair_style" class="col-md-4 col-form-label text-md-right">Hair Color Style:</label>
                        <select class="choose_plan" name="hairColor" id="hairColor">
                            <option value="0">Select Color:</option>
                            <?php while($row = mysqli_fetch_assoc($hair_color_sql)): ?>
                            <option value="<?php echo $row['hair_color_price']; ?>"><?php echo $row['hair_color_title']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="form-group row">
                        <label for="hair_style" class="col-md-4 col-form-label text-md-right">Hair Care:</label>
                        <div class="col-md-8">
                        <select class="choose_plan" name="hairCare" id="hairCare">
                            <option value="0">No</option>
                            <?php while($row = mysqli_fetch_assoc($hair_care_sql)): ?>
                            <option value="<?php echo $row['hair_care_price']; ?>">Yes</option>
                            <?php endwhile; ?>
                        </select>
                        <span>3000 Kyats</span>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="hair_style" class="col-md-4 col-form-label text-md-right">Date:</label>
                        <div class="col-md-8">
                            <i class="fas fa-calendar-alt form-fa-right"></i>
                            <input class="form-control choose_plan" id="date" name="date" data-date-format="mm-dd-yyyy" placeholder="MM/DD/YYY" type="text" autocomplete="off"/>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="hair_style" class="col-md-4 col-form-label text-md-right">Time:</label>
                        <div class="col-md-8">
                            <select class="choose_plan" name="time" id="time">
                                <option value="9:30AM">9:30 AM</option>
                                <option value="10:30AM">10:30 AM</option>
                                <option value="11:30AM">11:30 AM</option>
                                <option value="1:30PM">1:30 PM</option>
                                <option value="2:30PM">2:30 PM</option>
                                <option value="3:30PM">3:30 PM</option>
                                <option value="4:30PM">4:30 PM</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-8 offset-md-4">
                            <button type="submit" class="btn akame-btn">Book Now</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-4">

                <img src="img/bg-img/30.jpg" alt="">

            </div>
        </div>

    </section>

    <div class="modal" id="orderFormModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger">Fail</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Please Choose the at least one of the service.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>

    <div class="modal" id="orderSuccessModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-danger">Success</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Successfully Booking, thank you.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="successRedirect" data-dismiss="modal">Back</button>
            </div>
            </div>
        </div>
    </div>

<?php else: ?>
    <div class="container msg_body" style="	padding-top: 40px;
    text-align: center;
    padding-bottom: 40px;

    margin-top: 20px;
    margin-bottom: 20px;">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <a href="login-form.php" class="btn akame-btn">Login First</a>
            </div>
        </div>
    </div>

<?php endif; ?>


<?php include("layouts/footer.php"); ?>
<script>
    $(document).ready(function () {
        var date_input=$('input[name="date"]'); //our date input has the name "date"
          var options={
            format: 'mm-dd-yyyy',
            todayHighlight: true,
            startDate: new Date(),
            autoclose: true,
          };
          date_input.datepicker(options);

          $("form#order_form_submit").submit(function(e) {
            e.preventDefault();
            var user_id = $('#user_id').val();
            var stylist_id = $('#stylist_id').val();
            var hairCut = $('#hairCut').val();
            var hairColor = $('#hairColor').val();
            var hairCare = $('#hairCare').val();
            var date = $('#date').val();
            var time = $('#time').val();

            //console.log(stylist_id);

            $.ajax({
                url: "order.php",
                type: "POST",
                data: {
                    user_id: user_id,
                    stylist_id: stylist_id,
                    hairCut: hairCut,
                    hairColor : hairColor,
                    hairCare : hairCare,
                    date: date,
                    time: time,
                    },
                success: function(data,status) {
                    console.log(data);
                    if($.trim(data) == 'Choose the one service'){
                        console.log('NO');
                        $('#orderFormModal').modal();
                    }else{
                        console.log('Yes');
                        $('#orderSuccessModal').modal();

                    }
                }
            });

            $('#successRedirect').click(function(){
                window.location.href = 'index.php';
            });


          });




    });
</script>