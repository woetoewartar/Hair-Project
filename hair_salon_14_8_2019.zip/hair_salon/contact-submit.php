<?php
    include("admin/conf/config.php");

    $name = $_POST['message-name'];
    $email = $_POST['message-email'];
    $message = $_POST['message'];

    $sql = "INSERT INTO contact_us( name, email, message, create_at) VALUES ('$name','$email','$message',now())";
    mysqli_query($conn, $sql);

    header("location: msg-rev.php");


?>
