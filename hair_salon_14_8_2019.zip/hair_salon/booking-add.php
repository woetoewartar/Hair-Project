<?php
include("admin/conf/config.php");
$sql = "INSERT INTO bookings (user_id) VALUES ('2')";
mysqli_query($conn, $sql);
?>