<?php include('layouts/header.php'); ?>
    <section>
        <div class="container product_body">
                <div class="row">
                    <?php while($row = mysqli_fetch_assoc($services)): ?>
                        <div class="col-sm-3">
                            <div class="products">
                            <a href="">
                                <img src="./admin/images/<?php echo $row['image']; ?>">
                            </a>
                            <a href="./order_book.html">
                                <h4><?php echo $row['title']; ?></h4>
                            </a>
                            <!-- <p class="price"><?php echo $row['price']; ?> Kyats</p> -->
                            <?php if(isset($_SESSION['auth_user_id'])): ?>
                                <a href="order-page.php?id=<?php echo $row['stylist_id']; ?>" class="view-link shutter">
                                    <i class="fa fa-plus-circle"></i>
                                    Book Now
                                </a>
                            <?php else: ?>
                                <a href="" class="view-link shutter">
                                    <i class="fa fa-plus-circle"></i>
                                    Login Please
                                </a>
                            <?php endif; ?>
                            </div>

                        </div>

                    <?php endwhile; ?>


                </div>
        </div>
    </section>
<?php include('layouts/footer.php'); ?>