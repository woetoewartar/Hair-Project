<?php include("admin/conf/config.php");

$user_id = $_POST['user_id'];
$stylist_id = $_POST['stylist_id'];
$hairCut = $_POST['hairCut'];
$hairColor = $_POST['hairColor'];
$hairCare = $_POST['hairCare'];
$bdate = $_POST['date'];
$btime = $_POST['time'];

if ($hairCut == 0 && $hairColor == 0 && $hairCare == 0 ) {
    echo "Choose the one service";
}else {
    echo "success";
     $sql = "INSERT INTO orders (user_id, stylist_id, hair_cut_price, hair_color_price, hair_care_price, bdate, btime, create_at, update_at) VALUES ('$user_id','$stylist_id','$hairCut', '$hairColor', '$hairCare', '$bdate', '$btime', now(),now())";
     mysqli_query($conn, $sql);
}



?>
