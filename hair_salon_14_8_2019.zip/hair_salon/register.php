<?php include("admin/conf/config.php");


    if(isset($_POST['name'])){
        $name = $_POST['name'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $pass = password_hash($password, PASSWORD_BCRYPT);
        $user_check = "SELECT * FROM users WHERE email = '$email' ";

         $result = mysqli_query($conn,$user_check);
         $count = mysqli_num_rows($result);

        if($count == 1){
            echo "usernameExit";
        }else {
            echo "Successfully";

            $user_add = "INSERT INTO users (name,email,phone,password,role,create_at,update_at) VALUES ('$name','$email','$phone','$pass','bronze',now(),now())";
            mysqli_query($conn,$user_add);
            $user_id = mysqli_insert_id($conn);
            $_SESSION['auth_user_id'] = $user_id;
        }
    }

?>